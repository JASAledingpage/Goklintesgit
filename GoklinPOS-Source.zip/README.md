# Goklin POS — Native Android WebView

Native Android shell for the current Goklin POS web app.

- Application ID: `id.goklin.laundry.pos`
- Version: `1.0.0` / versionCode 1
- Portrait
- JavaScript + local storage enabled
- Internet permission enabled
- Goklin POS UI bundled in `app/src/main/assets/index.html`
- Supplied icon bundled and used as launcher icon
- WhatsApp links are handed to the Android WhatsApp/browser app

## Build

Open this folder in Android Studio and Build > Generate Signed Bundle/APK.

A GitHub Actions workflow is included in `.github/workflows/build.yml` to build a debug APK after uploading the project to GitHub.

## Important

The supplied `app.js` is preserved as `app-uploaded.js` for reference. The bundled `index.html` is the latest complete Goklin POS page from the user's Library and already contains its application logic. The supplied `app.js` is not injected into the page because it references UI functions not defined inside that file itself.

The web push/FCM browser service-worker flow is not converted into native Android FCM in this wrapper. The POS data/API functionality remains based on the bundled web app and its Google Apps Script endpoint.
