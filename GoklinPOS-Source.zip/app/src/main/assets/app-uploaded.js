// ============================================
// GOKLin POS Laundry - Main Application
// ============================================

// Konfigurasi
const CONFIG = {
  CLOUD_URL: 'https://script.google.com/macros/s/AKfycbyE_rThs8_8F-K1R22WWuE5X_8nKlpT1VpDxhA47WGSMGdQmklCe36i27bt_Hp8kCPz/exec',
  FIREBASE_CONFIG: {
    apiKey: "AIzaSyD3H8LBpYKpQylav3ih2CH3E8Y7GxM3ZS0",
    projectId: "goklin-pos-1bae4",
    messagingSenderId: "787509393508",
    appId: "1:787509393508:web:f5044a97d87564d7bd0771"
  },
  SERVICES: [
    { id: 1, name: '🧺 Cuci Biasa', price: 5000, unit: 'kg' },
    { id: 2, name: '✨ Cuci Ekspres', price: 8000, unit: 'kg' },
    { id: 3, name: '🧵 Setrika', price: 3000, unit: 'kg' },
    { id: 4, name: '👔 Dry Clean', price: 15000, unit: 'item' },
    { id: 5, name: '🛏️ Cuci Karpet', price: 25000, unit: 'm²' },
    { id: 6, name: '🧥 Cuci Jaket', price: 20000, unit: 'item' }
  ]
};

// State Aplikasi
let appState = {
  currentCustomer: null,
  cartItems: [],
  orders: [],
  customers: [],
  currentEditingOrder: null,
  notifications: [],
  serviceNamesMap: {}
};

// ============================================
// 1. INISIALISASI APLIKASI
// ============================================

document.addEventListener('DOMContentLoaded', async () => {
  console.log('🚀 GOKLin POS Laundry - Initializing...');
  
  await initFirebase();
  await registerServiceWorker();
  await loadDataFromLocalStorage();
  await loadDataFromGSheet();
  
  setupEventListeners();
  buildServiceNamesMap();
  renderServices();
  
  console.log('✅ Aplikasi siap!');
});

// Firebase Initialization
async function initFirebase() {
  try {
    if (!firebase.apps.length) {
      firebase.initializeApp(CONFIG.FIREBASE_CONFIG);
    }

    const messaging = firebase.messaging();
    
    // Request notification permission
    const permission = await Notification.requestPermission();
    if (permission === 'granted') {
      console.log('✅ Notifikasi diizinkan');
      
      try {
        // Untuk browser yang support
        const token = await messaging.getToken({ 
          vapidKey: 'BFN5XYQNzfMwDqGIwbL-Zx-ztV5bHXE-b5xXN9_vkf_Qzg4QS3h1v2e3RJu-K8QqZp1Z7X9Z4Z8Z1Z5Z9Z0Z'
        });
        if (token) {
          localStorage.setItem('fcmToken', token);
          console.log('📱 FCM Token:', token.substring(0, 20) + '...');
        }
      } catch (err) {
        console.log('⚠️ FCM token error:', err.message);
      }
    }

    // Handle foreground messages
    messaging.onMessage((payload) => {
      console.log('📬 Foreground message:', payload);
      const { title, body } = payload.notification;
      showToast(title, 'success', body);
      
      if (payload.data?.orderId) {
        updateOrderFromNotification(payload.data.orderId);
      }
    });

    console.log('✅ Firebase initialized');
  } catch (error) {
    console.error('❌ Firebase error:', error);
  }
}

// Register Service Worker
async function registerServiceWorker() {
  if ('serviceWorker' in navigator) {
    try {
      const registration = await navigator.serviceWorker.register('./firebase-messaging-sw.js');
      console.log('✅ Service Worker registered');

      // Listen untuk messages dari SW
      navigator.serviceWorker.addEventListener('message', (event) => {
        if (event.data.type === 'notification-click') {
          console.log('🔔 Notification clicked:', event.data);
          if (event.data.orderId) {
            switchTab('antrean');
            setTimeout(() => highlightOrder(event.data.orderId), 300);
          }
        }
      });
    } catch (error) {
      console.error('❌ SW registration error:', error);
    }
  }
}

// ============================================
// 2. DATA MANAGEMENT
// ============================================

// Build service names map untuk pencarian cepat
function buildServiceNamesMap() {
  CONFIG.SERVICES.forEach(service => {
    appState.serviceNamesMap[service.id] = service.name;
  });
}

// Load dari LocalStorage
function loadDataFromLocalStorage() {
  const stored = localStorage.getItem('goklin_data');
  if (stored) {
    try {
      const data = JSON.parse(stored);
      appState.orders = data.orders || [];
      appState.customers = data.customers || [];
      console.log('✅ Data loaded from localStorage:', appState.orders.length, 'orders');
    } catch (error) {
      console.error('❌ LocalStorage error:', error);
    }
  }
}

// Load dari GSheet
async function loadDataFromGSheet() {
  try {
    const response = await fetch(CONFIG.CLOUD_URL + '?action=getAll', {
      method: 'GET'
    });
    const data = await response.json();
    
    if (data.success) {
      if (data.orders) appState.orders = data.orders;
      if (data.customers) appState.customers = data.customers;
      console.log('✅ Data loaded from GSheet');
      saveDataToLocalStorage();
    }
  } catch (error) {
    console.log('⚠️ GSheet load error (offline mode):', error.message);
  }
}

// Save to LocalStorage
function saveDataToLocalStorage() {
  localStorage.setItem('goklin_data', JSON.stringify({
    orders: appState.orders,
    customers: appState.customers,
    lastSync: new Date().toISOString()
  }));
}

// Sync dengan GSheet
async function syncToGSheet() {
  const syncBtn = document.getElementById('syncBtn');
  const icon = document.getElementById('syncIcon');
  
  icon.textContent = '⟳';
  icon.style.animation = 'spin 1s linear infinite';
  syncBtn.disabled = true;

  try {
    const response = await fetch(CONFIG.CLOUD_URL, {
      method: 'POST',
      body: JSON.stringify({
        action: 'syncAll',
        orders: appState.orders,
        customers: appState.customers,
        timestamp
